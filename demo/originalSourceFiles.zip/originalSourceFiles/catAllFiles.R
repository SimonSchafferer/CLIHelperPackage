

setwd("/home/simon/RWorkspace/CLIHelperPackage/originalSourceFiles/")
allFiles = list.files("/home/simon/RWorkspace/CLIHelperPackage/originalSourceFiles/origFiles")

cmd = paste0("cat ", file.path("/home/simon/RWorkspace/CLIHelperPackage/originalSourceFiles/origFiles",allFiles), " >> singleRCodeFile.R" )
sapply(cmd, system )
