#'@include CLI_Application.R
NULL

#'@title OutResultReference Virtual Class
#'@section Slots: 
#'  \describe{
#'    \item{\code{slot1}:}{outResultName \code{"character"}}
#'  }
#' @name OutResultReference-class
#' @export
setClass("OutResultReference", representation(outResultName = "character", "VIRTUAL"))
#'@title FilesOutput
#'@section Slots: 
#'  \describe{
#'    \item{\code{slot1}:}{inFilePath \code{"character"}}
#'  }
#' @name FilesOutput-class
#' @export
setClass("FilesOutput", contains = "OutResultReference")
#'@title FoldersOutput
#'@section Slots: 
#'  \describe{
#'    \item{\code{slot1}:}{inFilePath \code{"character"}}
#'  }
#' @name FoldersOutput-class
#' @export
setClass("FoldersOutput", contains = "OutResultReference")

#' @title Constructor method for FoldersOutput
#' @param outResultName
#' @export
#' @docType methods
#' @return \code{"FoldersOutput"}
FoldersOutput = function(outResultName){
  return( new("FoldersOutput", outResultName=outResultName) )
}
#' @title Constructor method for FilesOutput
#' @param outResultName
#' @export
#' @docType methods
#' @return \code{"FilesOutput"}
FilesOutput = function(outResultName){
  return( new("FilesOutput", outResultName=outResultName) )
}

#' @title Constructor (factory) for OutResultReference
#' @param outResultName
#' @export
#' @docType methods
#' @return \code{OutResultReference} implementation
OutResultReference = function(outResultName){
  if( file.exists(outResultName) ){
    if( length(list.files(outResultName)) == 0 ){
      return( FilesOutput(outResultName)  )
    } else{
      return( FoldersOutput(outResultName)  )
    }
  } else{
    stop("Not a file or folder!")
  } 
} 

#'@title CmdGenResult
#'@section Slots: 
#'  \describe{
#'    \item{\code{slot1}:}{CLIApplication \code{"CLIApplication"}}
#'    \item{\code{slot2}:}{OutResultReference \code{"OutResultReference"}}
#'    \item{\code{slot3}:}{commands \code{"character"}}
#'    \item{\code{slot4}:}{executed \code{"logical"}}
#'  }
#' @name CmdGenResult-class
#' @export
setClass( "CmdGenResult", representation( CLIApplication="CLIApplication",
                                          OutResultReference="OutResultReference",
                                          commands="character",
                                          executed="logical" ) )

setValidity ("CmdGenResult",
             function ( object ){
               retval = NULL
               if ( is.null(retval)){
                 return(TRUE)
               }
               else{
                 return(retval)
               }
             })

#' @title Accessor CLIApplication
#' @export
#' @docType methods
#' @return CLIApplication
setGeneric("getCLIApplication", function(object) standardGeneric("getCLIApplication"))
setMethod("getCLIApplication",signature(object="CmdGenResult"),function(object) {
  slot(object, "CLIApplication")
})

#' @title Accessor getOutResultReference
#' @export
#' @docType methods
#' @return OutResultReference
setGeneric("getOutResultReference", function(object) standardGeneric("getOutResultReference"))
setMethod("getOutResultReference",signature(object="CmdGenResult"),function(object) {
  slot(object, "OutResultReference")
})

#' @title Accessor getCommands
#' @export
#' @docType methods
#' @return commands
setGeneric("getCommands", function(object) standardGeneric("getCommands"))
setMethod("getCommands",signature(object="CmdGenResult"),function(object) {
  slot(object, "commands")
})
#' @title Accessor isExecuted
#' @export
#' @docType methods
#' @return \code{"executed"}
setGeneric("isExecuted", function(object) standardGeneric("isExecuted"))
setMethod("isExecuted",signature(object="CmdGenResult"),function(object) {
  slot(object, "executed")
})

#' @title Constructor method for CmdGenResult
#' @param CLIApplication
#' @param OutResultReference
#' @param commands
#' @param executed
#' @export
#' @docType methods
#' @return \code{"CmdGenResult"}
CmdGenResult = function(CLIApplication,OutResultReference,commands,executed ){
  return( new("CmdGenResult",CLIApplication=CLIApplication,OutResultReference=OutResultReference,commands=commands,executed=executed) )
}

#' @title Executes the commands of a executeCommandResult object
#' @param \code{"CmdGenResult"}
#' @export
#' @docType methods
setGeneric("executeCommandResult", function( object ) { standardGeneric("executeCommandResult") })
setMethod("executeCommandResult",signature(object="CmdGenResult"), function(object) {
  message( paste0("Executing command:\n", paste0(getCommands(object), collapse="\n")) )
#   system(getCommands(object))
  object@executed = TRUE
  return(object)
})
